from cgikits import *

resp = """Content-Type: text/json

{
    "abc": "111",
    "qwe": "222"
}
"""

print(resp)
